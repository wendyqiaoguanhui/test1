create trigger T_STUDENT_TRIGGER
  before insert
  on STUDENT
  for each row
  begin
  select t_student_seq.nextval into :new.id from dual;
end;
/

